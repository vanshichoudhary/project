// Fix for missing Sign In button on desktop
document.addEventListener('DOMContentLoaded', function() {
    function fixSignInButton() {
        // Check if the sign in button is present in the DOM
        const signInButtons = document.querySelectorAll('.signin-button');

        // Log for debugging
        console.log('SignIn buttons found:', signInButtons.length);

        // Check if any buttons are hidden in desktop view
        signInButtons.forEach(button => {
            const parentEl = button.closest('.flex.items-center');
            if (parentEl) {
                // Make sure parent elements are visible on desktop
                const computedStyle = window.getComputedStyle(parentEl);
                console.log('SignIn button parent display:', computedStyle.display);

                // Force visibility on desktop
                if (window.innerWidth >= 768) { // md breakpoint in Tailwind
                    parentEl.style.display = 'flex';

                    // Find nearest ancestor with 'hidden' class
                    let ancestor = parentEl.parentElement;
                    while (ancestor) {
                        if (ancestor.classList.contains('hidden')) {
                            // Force this to be visible on desktop
                            ancestor.classList.remove('hidden');
                            ancestor.classList.add('flex');
                            console.log('Fixed hidden ancestor:', ancestor);
                        }

                        // Check parent with md:hidden
                        if (ancestor.classList.contains('md:hidden')) {
                            // Remove md:hidden and add md:flex
                            ancestor.classList.remove('md:hidden');
                            ancestor.classList.add('md:flex');
                            console.log('Fixed md:hidden ancestor:', ancestor);
                        }

                        ancestor = ancestor.parentElement;
                    }
                }
            }
        });
    }

    // Run on load and resize
    fixSignInButton();
    window.addEventListener('resize', fixSignInButton);
});