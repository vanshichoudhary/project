import { toast } from "@/components/ui/use-toast";

const emailRegex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
const mailchimpRegex = /^https?:\/\/([^\/]+)[^\?]+\??(.+)$/;

export const validateEmail = (email: string): boolean => {
  return emailRegex.test(String(email).toLowerCase());
};

const parseMailChimpUrl = (url: string) => {
  const [, domain, parameters] = url
    .replace("&amp;", "&")
    .match(mailchimpRegex) ?? [null, null, null];

  return [domain, new URLSearchParams(parameters)] as const;
};

export const MAILCHIMP_URL = "https://nynexafoundation.us21.list-manage.com/subscribe/post?u=1487cc549a49109c00fe60a80&id=93cd7be172";

export interface MailchimpSubscribeResult {
  success: boolean;
  message: string;
}

export const subscribeToMailchimp = async (email: string): Promise<MailchimpSubscribeResult> => {
  if (!validateEmail(email)) {
    return {
      success: false,
      message: "Please provide a valid email address",
    };
  }

  try {
    const [domain, parameters] = parseMailChimpUrl(MAILCHIMP_URL);

    if (!domain || !parameters) {
      throw new Error("Invalid Mailchimp URL configuration");
    }

    parameters.set("MERGE0", email); // MERGE0 is Mailchimp's email field name
    parameters.set("b_1487cc549a49109c00fe60a80_93cd7be172", ""); // Honeypot field for bot protection

    const response = await fetch(`https://${domain}/subscribe/post`, {
      method: "POST",
      mode: "no-cors", // Mailchimp requires this mode
      headers: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
      },
      body: parameters.toString(),
    });

    // Since mode is no-cors, we can't actually check the response status
    // We'll assume success if no error is thrown
    return {
      success: true,
      message: "Thank you for subscribing to our newsletter!",
    };
  } catch (error) {
    console.error("Mailchimp subscription error:", error);
    return {
      success: false,
      message: "There was a problem subscribing you to the newsletter. Please try again.",
    };
  }
}; 