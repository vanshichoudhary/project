import React, { Suspense, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Header from "./Header";
import Footer from "./Footer";
import { Toaster } from "@/components/ui/toaster";
import ErrorBoundary from "@/components/shared/ErrorBoundary";
import LoadingSpinner from "@/components/shared/LoadingSpinner";
import { isSamsungDevice, applySamsungFixes } from "@/utils/mobileFix";
import { Analytics } from "@vercel/analytics/react";
import { SpeedInsights } from "@vercel/speed-insights/react";

interface MainLayoutProps {
  children: React.ReactNode;
  hideHeader?: boolean;
  hideFooter?: boolean;
}

const MainLayout = ({
  children,
  hideHeader = false,
  hideFooter = false,
}: MainLayoutProps) => {
  // Fix for Samsung devices showing blank sections
  useEffect(() => {
    // Check if this is a Samsung device and apply the fixes
    if (isSamsungDevice()) {
      console.log("Samsung device detected in MainLayout, applying fixes");
      
      // Apply fixes immediately and after a delay for dynamic content
      applySamsungFixes();
      
      // Set multiple timeouts to catch any lazy-loaded content
      const timeouts = [100, 300, 800, 1500].map(delay => 
        setTimeout(applySamsungFixes, delay)
      );
      
      // Clean up timeouts on unmount
      return () => {
        timeouts.forEach(clearTimeout);
      };
    }
  }, []);

  return (
    <ErrorBoundary>
      <div className="flex flex-col min-h-screen bg-white">
        {!hideHeader && <Header />}
        <Suspense fallback={<LoadingSpinner size="md" text="Loading content..." />}>
          <AnimatePresence mode="wait">
            <motion.main
              className="flex-grow mobile-compatible-content"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              style={{
                willChange: 'transform',
                isolation: 'isolate',
                contain: 'paint layout'
              }}
              data-mobile-fix="true"
            >
              {/* Samsung device layout fix - hidden content marker */}
              <div className="force-render" aria-hidden="true" style={{ display: 'none' }}></div>
              
              {children}
              
              {/* Samsung device layout fix - hidden content marker */}
              <div className="force-render" aria-hidden="true" style={{ display: 'none' }}></div>
            </motion.main>
          </AnimatePresence>
        </Suspense>
        {!hideFooter && <Footer />}
        <Toaster />
        <Analytics />
        <SpeedInsights />
        
        {/* Hidden element to force browser to calculate layout for Samsung devices */}
        <div className="hidden" aria-hidden="true" id="samsung-fix-container">
          <div className="force-render force-content-visibility"></div>
        </div>
      </div>
    </ErrorBoundary>
  );
};

export default MainLayout;
