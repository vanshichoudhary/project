import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { ChevronDown, LogIn, UserCircle, LayoutDashboard } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SignInButton, SignedIn, SignedOut, UserButton } from "@clerk/clerk-react";

type MobileNavProps = {
  onClose: () => void;
  isAuth: boolean;
  onSignIn: () => void;
  onSignOut: () => void;
};

const MobileNav = ({ onClose, isAuth, onSignIn, onSignOut }: MobileNavProps) => {
  const [activeMegaMenu, setActiveMegaMenu] = useState<string | null>(null);

  const toggleMegaMenu = (menu: string) => {
    setActiveMegaMenu(activeMegaMenu === menu ? null : menu);
  };

  const mobileMenuVariants = {
    closed: { opacity: 0, y: -20 },
    open: { opacity: 1, y: 0, transition: { duration: 0.3 } },
  };

  const buttonVariants = {
    hover: { scale: 1.03, transition: { duration: 0.2 } },
    tap: { scale: 0.97 },
  };

  return (
    <motion.div
      className="fixed inset-0 z-40 bg-white pt-20 px-4 overflow-y-auto md:hidden"
      variants={mobileMenuVariants}
      initial="closed"
      animate="open"
      exit="closed"
    >
      <nav className="flex flex-col space-y-4 py-6">
        <div className="border-b pb-4">
          <div
            className="flex items-center justify-between py-2"
            onClick={() => toggleMegaMenu("work-mobile")}
          >
            <span className="text-lg font-medium">Our Work</span>
            <ChevronDown
              className={`h-5 w-5 transition-transform ${
                activeMegaMenu === "work-mobile" ? "rotate-180" : ""
              }`}
            />
          </div>
          <AnimatePresence>
            {activeMegaMenu === "work-mobile" && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="py-2 pl-4 space-y-2">
                  <Link
                    to="/work/research-development"
                    className="block py-2 text-gray-700 hover:text-black"
                    onClick={onClose}
                  >
                    Research & Development
                  </Link>
                  <Link
                    to="/work/billionaire-fund"
                    className="block py-2 text-gray-700 hover:text-black"
                    onClick={onClose}
                  >
                    Billionaire Fund
                  </Link>
                  <Link
                    to="/work/education-stem"
                    className="block py-2 text-gray-700 hover:text-black"
                    onClick={onClose}
                  >
                    Education & STEM
                  </Link>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="border-b pb-4">
          <div
            className="flex items-center justify-between py-2"
            onClick={() => toggleMegaMenu("about-mobile")}
          >
            <span className="text-lg font-medium">About</span>
            <ChevronDown
              className={`h-5 w-5 transition-transform ${
                activeMegaMenu === "about-mobile" ? "rotate-180" : ""
              }`}
            />
          </div>
          <AnimatePresence>
            {activeMegaMenu === "about-mobile" && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="py-2 pl-4 space-y-2">
                  <Link
                    to="/about/vision-mission"
                    className="block py-2 text-gray-700 hover:text-black"
                    onClick={onClose}
                  >
                    Vision & Mission
                  </Link>
                  <Link
                    to="/about/governance"
                    className="block py-2 text-gray-700 hover:text-black"
                    onClick={onClose}
                  >
                    Governance, Leadership & Transparency
                  </Link>
                  <Link
                    to="/about/timeline"
                    className="block py-2 text-gray-700 hover:text-black"
                    onClick={onClose}
                  >
                    History & Timeline
                  </Link>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <Link
          to="/news"
          className="block py-2 text-lg font-medium border-b pb-4"
          onClick={onClose}
        >
          News
        </Link>

        <Link
          to="/contact"
          className="block py-2 text-lg font-medium border-b pb-4"
          onClick={onClose}
        >
          Contact
        </Link>

        <div className="pt-4 mt-4 border-t flex flex-col space-y-4">
          <div className="flex items-center justify-center">
            <SignedIn>
              <div className="flex flex-col items-center gap-2">
                <UserButton 
                  afterSignOutUrl="/"
                  appearance={{
                    elements: {
                      userButtonAvatarBox: "h-14 w-14",
                      userButtonBox: "w-full flex justify-center"
                    }
                  }} 
                />
                <span className="text-sm text-gray-600">Manage account</span>
              </div>
            </SignedIn>
          </div>
          
          <SignedOut>
            <SignInButton mode="modal">
              <button className="signin-button w-full justify-center py-2">
                <LogIn className="h-4 w-4 mr-2" />
                Sign in to your account
              </button>
            </SignInButton>
          </SignedOut>

          <SignedIn>
            <div className="flex flex-col space-y-3 pt-2 border-t border-gray-100">
              <Link to="/profile" onClick={onClose} className="flex items-center px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-md">
                <UserCircle className="h-5 w-5 mr-2" />
                <span>Profile</span>
              </Link>
              <Link to="/dashboard" onClick={onClose} className="flex items-center px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-md">
                <LayoutDashboard className="h-5 w-5 mr-2" />
                <span>Dashboard</span>
              </Link>
            </div>
          </SignedIn>
  
          <Link to="/get-involved/donate" onClick={onClose}>
            <button className="donate-button-mobile">
              Donate
            </button>
          </Link>
          
          {isAuth && (
            <Button
              onClick={onSignOut}
              variant="outline"
              className="w-full justify-center border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              Sign Out from Other Services
            </Button>
          )}
        </div>
      </nav>
    </motion.div>
  );
};

export default MobileNav; 