import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import {
  Menu,
  X,
  ChevronDown,
  User,
  LogOut,
  Settings,
  Heart,
  Search,
  UserCircle,
  LogIn,
  LayoutDashboard
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import MegaMenu from "@/components/navigation/MegaMenu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { SignInButton, SignedIn, SignedOut, UserButton } from "@clerk/clerk-react";
import MobileNav from "./MobileNav";

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeMegaMenu, setActiveMegaMenu] = useState<string | null>(null);
  const { user, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
    setActiveMegaMenu(null);
  }, [location.pathname]);

  const toggleMegaMenu = (menuId: string) => {
    if (activeMegaMenu === menuId) {
      setActiveMegaMenu(null);
    } else {
      setActiveMegaMenu(menuId);
    }
  };

  const closeMegaMenu = () => {
    setActiveMegaMenu(null);
  };

  const headerVariants = {
    initial: { y: -100 },
    animate: {
      y: 0,
      transition: { type: "spring", stiffness: 100, damping: 20 },
    },
  };

  const mobileMenuVariants = {
    closed: { opacity: 0, x: "-100%", transition: { duration: 0.3 } },
    open: { opacity: 1, x: 0, transition: { duration: 0.3 } },
  };

  const megaMenuVariants = {
    hidden: { opacity: 0, y: -20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.3 } },
  };

  const buttonVariants = {
    hover: { scale: 1.03, transition: { duration: 0.2 } },
    tap: { scale: 0.97 },
  };

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  const toggleMobileNav = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <>
      <motion.header
        className={`fixed top-0 left-0 right-0 z-50 ${
          isScrolled ? "bg-white border-b border-gray-200 shadow-sm" : "bg-white"
        } transition-all duration-300`}
        variants={headerVariants}
        initial="initial"
        animate="animate"
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center">
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="text-2xl font-bold text-black"
              >
                Nynexa Foundation
              </motion.div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-1">
              <div
                className="relative px-2 py-2 cursor-pointer"
                onMouseEnter={() => toggleMegaMenu("work")}
                onMouseLeave={() => closeMegaMenu()}
              >
                <div className="flex items-center text-gray-800 hover:text-black transition-colors font-medium">
                  <span>Our Work</span>
                  <ChevronDown
                    className={`ml-1 h-4 w-4 transition-transform ${activeMegaMenu === "work" ? "rotate-180" : ""}`}
                  />
                </div>
                <AnimatePresence>
                  {activeMegaMenu === "work" && (
                    <motion.div
                      className="absolute left-0 mt-2 w-screen max-w-4xl bg-white shadow-xl border border-gray-200"
                      style={{ left: "-150px" }}
                      variants={megaMenuVariants}
                      initial="hidden"
                      animate="visible"
                      exit="hidden"
                    >
                      <MegaMenu
                        type="work"
                        onClose={() => setActiveMegaMenu(null)}
                      />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div
                className="relative px-2 py-2 cursor-pointer"
                onMouseEnter={() => toggleMegaMenu("about")}
                onMouseLeave={() => closeMegaMenu()}
              >
                <div className="flex items-center text-gray-800 hover:text-black transition-colors font-medium">
                  <span>About</span>
                  <ChevronDown
                    className={`ml-1 h-4 w-4 transition-transform ${activeMegaMenu === "about" ? "rotate-180" : ""}`}
                  />
                </div>
                <AnimatePresence>
                  {activeMegaMenu === "about" && (
                    <motion.div
                      className="absolute left-0 mt-2 w-screen max-w-4xl bg-white shadow-xl border border-gray-200"
                      style={{ left: "-300px" }}
                      variants={megaMenuVariants}
                      initial="hidden"
                      animate="visible"
                      exit="hidden"
                    >
                      <MegaMenu
                        type="about"
                        onClose={() => setActiveMegaMenu(null)}
                      />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <Link
                to="/news"
                className="px-2 py-2 text-gray-800 hover:text-black transition-colors font-medium"
              >
                News
              </Link>

              <Link
                to="/contact"
                className="px-2 py-2 text-gray-800 hover:text-black transition-colors font-medium"
              >
                Contact
              </Link>
            </nav>

            {/* Auth and Search Section - ALWAYS visible on desktop */}
            <div className="flex items-center space-x-2">
              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-gray-600 hover:text-black hover:bg-gray-100"
                    aria-label="Search"
                  >
                    <Search className="h-5 w-5" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle>Search our website</DialogTitle>
                    <DialogDescription>
                      Find information about our programs, initiatives, and
                      more.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="relative">
                      <Search className="absolute left-2 top-3 h-4 w-4 text-gray-500" />
                      <input
                        className="flex h-10 w-full rounded-md border border-input bg-background px-9 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        placeholder="Search..."
                      />
                    </div>
                  </div>
                </DialogContent>
              </Dialog>

              <div className="hidden md:flex items-center">
                <SignedIn>
                  <UserButton 
                    afterSignOutUrl="/"
                    appearance={{
                      elements: {
                        userButtonAvatarBox: "h-10 w-10",
                        userButtonBox: "h-10 w-10",
                        userButtonOuterIdentifier: "hidden",
                        userButtonTrigger: "ring-offset-background ring-black focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                      }
                    }}
                  />
                </SignedIn>
                <SignedOut>
                  <SignInButton mode="modal">
                    <button className="signin-button mr-2">
                      <LogIn className="h-4 w-4 mr-1" />
                      Sign in
                    </button>
                  </SignInButton>
                </SignedOut>
              </div>

              {/* Donate Button - DESKTOP ONLY */}
              <div className="hidden md:block">
                <Link to="/get-involved/donate">
                  <button className="donate-button">
                    Donate
                  </button>
                </Link>
              </div>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden flex items-center">
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleMobileNav}
                aria-label="Toggle menu"
                className="text-black hover:bg-gray-100"
              >
                {isMobileMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <MobileNav
            onClose={() => setIsMobileMenuOpen(false)}
            isAuth={!!user}
            onSignIn={() => navigate("/auth/login")}
            onSignOut={handleSignOut}
          />
        )}
      </AnimatePresence>

      {/* Spacer for fixed header */}
      <div className="h-20"></div>
    </>
  );
};

export default Header;
