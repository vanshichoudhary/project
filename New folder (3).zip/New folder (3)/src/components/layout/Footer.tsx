import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import {
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  Youtube,
  ArrowRight,
  Mail,
  CheckCircle,
  Loader2
} from "lucide-react";
import { subscribeToMailchimp } from "@/lib/mailchimp";

const Footer = () => {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const { toast } = useToast();

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsSubmitting(true);
    try {
      const result = await subscribeToMailchimp(email);
      
      if (result.success) {
        setIsSuccess(true);
        toast({
          title: "Subscription successful!",
          description: result.message,
        });
        setEmail("");
      } else {
        throw new Error(result.message);
      }
    } catch (error: any) {
      toast({
        title: "Subscription failed",
        description: error.message || "There was an error subscribing to the newsletter.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const footerAnimation = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        staggerChildren: 0.1,
      },
    },
  };

  const itemAnimation = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  const socialIconAnimation = {
    hover: { scale: 1.2, rotate: 5, transition: { duration: 0.2 } },
  };

  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={footerAnimation}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12"
        >
          <motion.div variants={itemAnimation} className="space-y-4">
            <h3 className="text-lg font-semibold">About Nynexa</h3>
            <p className="text-gray-400">
              The Nynexa Foundation is dedicated to advancing humanity through
              groundbreaking research, education, and strategic philanthropy.
            </p>
            <div className="flex space-x-4">
              <motion.a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                variants={socialIconAnimation}
                whileHover="hover"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <Facebook size={20} />
              </motion.a>
              <motion.a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                variants={socialIconAnimation}
                whileHover="hover"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <Twitter size={20} />
              </motion.a>
              <motion.a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                variants={socialIconAnimation}
                whileHover="hover"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <Linkedin size={20} />
              </motion.a>
              <motion.a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                variants={socialIconAnimation}
                whileHover="hover"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <Instagram size={20} />
              </motion.a>
              <motion.a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                variants={socialIconAnimation}
                whileHover="hover"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <Youtube size={20} />
              </motion.a>
            </div>
          </motion.div>

          <motion.div variants={itemAnimation} className="space-y-4">
            <h3 className="text-lg font-semibold">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  to="/about"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  About Us
                </Link>
              </li>
              <li>
                <Link
                  to="/work/research-development"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Research & Development
                </Link>
              </li>
              <li>
                <Link
                  to="/work/billionaire-fund"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Billionaire Fund
                </Link>
              </li>
              <li>
                <Link
                  to="/work/education-stem"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Education & STEM
                </Link>
              </li>
              <li>
                <Link
                  to="/news"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  News & Updates
                </Link>
              </li>
            </ul>
          </motion.div>

          <motion.div variants={itemAnimation} className="space-y-4">
            <h3 className="text-lg font-semibold">Get Involved</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  to="/get-involved/donate"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Make a Donation
                </Link>
              </li>
              <li>
                <Link
                  to="/get-involved/partners"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Partnerships
                </Link>
              </li>
              <li>
                <Link
                  to="/get-involved/donate"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Volunteer
                </Link>
              </li>
              <li>
                <Link
                  to="/get-involved/careers"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Careers
                </Link>
              </li>
              <li>
                <Link
                  to="/contact"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Contact Us
                </Link>
              </li>
            </ul>
          </motion.div>

          <motion.div variants={itemAnimation} className="space-y-4">
            <h3 className="text-lg font-semibold">Newsletter</h3>
            <p className="text-gray-400">
              Subscribe to our newsletter for the latest updates on our work and
              impact.
            </p>
            {isSuccess ? (
              <div className="flex items-center space-x-2 text-white p-4 bg-gray-800 rounded-lg">
                <CheckCircle className="h-5 w-5 text-green-500" />
                <p className="text-sm">Thank you for subscribing!</p>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="space-y-2">
                <div className="flex">
                  <div className="relative flex-grow">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <Input
                      type="email"
                      placeholder="Your email address"
                      className="pl-10 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500 w-full"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                    <input
                      type="text"
                      tabIndex={-1}
                      name="b_1487cc549a49109c00fe60a80_93cd7be172"
                      style={{ position: "absolute", left: "-5000px" }}
                      aria-hidden="true"
                    />
                  </div>
                  <Button
                    type="submit"
                    className="ml-2 bg-black hover:bg-black-800"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      "Subscribe"
                    )}
                  </Button>
                </div>
                <p className="text-xs text-gray-500">
                  By subscribing, you agree to our{" "}
                  <Link
                    to="/privacy-policy"
                    className="text-black hover:text-black-600"
                  >
                    Privacy Policy
                  </Link>
                  .
                </p>
              </form>
            )}
          </motion.div>
        </motion.div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={footerAnimation}
          className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center"
        >
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            © {new Date().getFullYear()} Nynexa Foundation. All rights reserved.
          </p>
          <div className="flex space-x-4 text-sm text-gray-400">
            <Link
              to="/privacy-policy"
              className="hover:text-white transition-colors"
            >
              Privacy Policy
            </Link>
            <span className="text-gray-600">|</span>
            <Link
              to="/terms-of-use"
              className="hover:text-white transition-colors"
            >
              Terms of Use
            </Link>
            <span className="text-gray-600">|</span>
            <Link
              to="/cookie-policy"
              className="hover:text-white transition-colors"
            >
              Cookie Policy
            </Link>
          </div>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;
