import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Lightbulb,
  Landmark,
  GraduationCap,
  Users,
  Award,
  Building,
  BarChart,
  ArrowRight,
  Clock,
  Briefcase,
} from "lucide-react";

interface MegaMenuProps {
  type: "work" | "about";
  onClose: () => void;
}

const MegaMenu: React.FC<MegaMenuProps> = ({ type, onClose }) => {
  const menuVariants = {
    hidden: { opacity: 0, y: -20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.3,
        staggerChildren: 0.05,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { opacity: 1, y: 0 },
  };

  const renderWorkMenu = () => (
    <div className="grid grid-cols-3 gap-8 p-8">
      <motion.div variants={itemVariants} className="col-span-1">
        <Link
          to="/work/research-development"
          className="group flex items-start"
          onClick={onClose}
        >
          <div className="mr-4 p-3 bg-black-100 rounded-lg group-hover:bg-black-200 transition-colors">
            <Lightbulb className="h-6 w-6 text-black-700" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900 group-hover:text-black-700 transition-colors">
              Research & Development
            </h3>
            <p className="text-gray-600 mt-1">
              Pioneering breakthrough technologies and scientific advancements
            </p>
            <span className="inline-flex items-center mt-2 text-black-700 font-medium group-hover:translate-x-1 transition-transform">
              Learn more <ArrowRight className="ml-1 h-4 w-4" />
            </span>
          </div>
        </Link>
      </motion.div>

      <motion.div variants={itemVariants} className="col-span-1">
        <Link
          to="/work/billionaire-fund"
          className="group flex items-start"
          onClick={onClose}
        >
          <div className="mr-4 p-3 bg-black-100 rounded-lg group-hover:bg-black-200 transition-colors">
            <Landmark className="h-6 w-6 text-black-700" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900 group-hover:text-black-700 transition-colors">
              Billionaire Fund
            </h3>
            <p className="text-gray-600 mt-1">
              Strategic investments in transformative global initiatives
            </p>
            <span className="inline-flex items-center mt-2 text-black-700 font-medium group-hover:translate-x-1 transition-transform">
              Learn more <ArrowRight className="ml-1 h-4 w-4" />
            </span>
          </div>
        </Link>
      </motion.div>

      <motion.div variants={itemVariants} className="col-span-1">
        <Link
          to="/work/education-stem"
          className="group flex items-start"
          onClick={onClose}
        >
          <div className="mr-4 p-3 bg-black-100 rounded-lg group-hover:bg-black-200 transition-colors">
            <GraduationCap className="h-6 w-6 text-black-700" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900 group-hover:text-black-700 transition-colors">
              Education & STEM
            </h3>
            <p className="text-gray-600 mt-1">
              Empowering the next generation through educational initiatives
            </p>
            <span className="inline-flex items-center mt-2 text-black-700 font-medium group-hover:translate-x-1 transition-transform">
              Learn more <ArrowRight className="ml-1 h-4 w-4" />
            </span>
          </div>
        </Link>
      </motion.div>

      <motion.div variants={itemVariants} className="col-span-3">
        <div className="mt-4 pt-6 border-t border-gray-200">
          <h4 className="text-sm font-semibold text-gray-500 mb-4">
            EXPLORE OUR IMPACT
          </h4>
          <div className="grid grid-cols-2 gap-4">
            <Link
              to="/impact/stories"
              className="text-gray-700 hover:text-black-700 transition-colors flex items-center"
              onClick={onClose}
            >
              <ArrowRight className="mr-2 h-4 w-4" /> Impact Stories
            </Link>
            <Link
              to="/impact/reports"
              className="text-gray-700 hover:text-black-700 transition-colors flex items-center"
              onClick={onClose}
            >
              <ArrowRight className="mr-2 h-4 w-4" /> Annual Reports
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );

  const renderAboutMenu = () => (
    <div className="grid grid-cols-3 gap-6 p-8">
      <motion.div variants={itemVariants} className="col-span-1">
        <Link
          to="/about/vision-mission"
          className="group flex flex-col"
          onClick={onClose}
        >
          <div className="mb-3 p-3 bg-black-100 rounded-lg w-12 h-12 flex items-center justify-center group-hover:bg-black-200 transition-colors">
            <Award className="h-6 w-6 text-black-700" />
          </div>
          <h3 className="text-base font-semibold text-gray-900 group-hover:text-black-700 transition-colors">
            Vision & Mission
          </h3>
          <p className="text-sm text-gray-600 mt-1">
            Our guiding principles and goals
          </p>
        </Link>
      </motion.div>

      <motion.div variants={itemVariants} className="col-span-1">
        <Link
          to="/about/timeline"
          className="group flex flex-col"
          onClick={onClose}
        >
          <div className="mb-3 p-3 bg-black-100 rounded-lg w-12 h-12 flex items-center justify-center group-hover:bg-black-200 transition-colors">
            <Clock className="h-6 w-6 text-black-700" />
          </div>
          <h3 className="text-base font-semibold text-gray-900 group-hover:text-black-700 transition-colors">
            History & Timeline
          </h3>
          <p className="text-sm text-gray-600 mt-1">
            Our journey from vision to impact
          </p>
        </Link>
      </motion.div>

      <motion.div variants={itemVariants} className="col-span-1">
        <Link
          to="/about/governance"
          className="group flex flex-col"
          onClick={onClose}
        >
          <div className="mb-3 p-3 bg-black-100 rounded-lg w-12 h-12 flex items-center justify-center group-hover:bg-black-200 transition-colors">
            <BarChart className="h-6 w-6 text-black-700" />
          </div>
          <h3 className="text-base font-semibold text-gray-900 group-hover:text-black-700 transition-colors">
            Governance, Leadership & Transparency
          </h3>
          <p className="text-sm text-gray-600 mt-1">
            Our structure, leadership, and commitment to accountability
          </p>
        </Link>
      </motion.div>

      <motion.div variants={itemVariants} className="col-span-3">
        <div className="mt-6 p-6 bg-gray-50 rounded-lg">
          <div className="flex items-start">
            <div className="flex-shrink-0">
              <img
                src="https://images.unsplash.com/photo-1557804506-669a67965ba0?w=300&q=80"
                alt="Annual Report"
                className="h-24 w-24 object-cover rounded-md"
              />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-900">
                2023 Annual Impact Report
              </h3>
              <p className="text-gray-600 mt-1">
                Explore how our initiatives have transformed lives and advanced
                scientific progress over the past year.
              </p>
              <Link
                to="/impact/reports/2023"
                className="inline-flex items-center mt-2 text-black-700 font-medium hover:underline"
                onClick={onClose}
              >
                Read the report <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );

  return (
    <motion.div
      className="bg-white rounded-lg shadow-xl border border-gray-200 overflow-hidden w-full"
      variants={menuVariants}
      initial="hidden"
      animate="visible"
      exit="hidden"
    >
      {type === "work" && renderWorkMenu()}
      {type === "about" && renderAboutMenu()}
    </motion.div>
  );
};

export default MegaMenu;
