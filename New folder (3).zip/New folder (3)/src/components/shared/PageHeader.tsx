import React from "react";
import { motion } from "framer-motion";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  backgroundImage?: string;
  alignment?: "left" | "center" | "right";
  size?: "small" | "medium" | "large";
  overlay?: boolean;
  textColor?: "light" | "dark";
  children?: React.ReactNode;
}

const PageHeader: React.FC<PageHeaderProps> = ({
  title,
  subtitle,
  backgroundImage,
  alignment = "center",
  size = "medium",
  overlay = true,
  textColor = "light",
  children,
}) => {
  const getHeight = () => {
    switch (size) {
      case "small":
        return "h-64";
      case "large":
        return "h-[500px]";
      case "medium":
      default:
        return "h-96";
    }
  };

  const getAlignment = () => {
    switch (alignment) {
      case "left":
        return "text-left items-start";
      case "right":
        return "text-right items-end";
      case "center":
      default:
        return "text-center items-center";
    }
  };

  const getTextColor = () => {
    return textColor === "light" ? "text-white" : "text-gray-900";
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        duration: 0.6,
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <div
      className={`relative ${getHeight()} overflow-hidden bg-black-900 flex items-center`}
    >
      {backgroundImage && (
        <div className="absolute inset-0 w-full h-full">
          <motion.div
            initial={{ scale: 1.1 }}
            animate={{ scale: 1 }}
            transition={{ duration: 1.5 }}
            className="w-full h-full"
          >
            <img
              src={backgroundImage}
              alt={title}
              className="w-full h-full object-cover"
            />
          </motion.div>
          {overlay && (
            <div
              className={`absolute inset-0 bg-gradient-to-r from-black-900/80 to-black-700/70`}
            ></div>
          )}
        </div>
      )}

      <motion.div
        className={`container mx-auto px-4 relative z-10 flex flex-col ${getAlignment()} justify-center`}
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.h1
          className={`text-4xl md:text-5xl lg:text-6xl font-bold mb-4 ${getTextColor()}`}
          variants={itemVariants}
        >
          {title}
        </motion.h1>
        {subtitle && (
          <motion.p
            className={`text-lg md:text-xl max-w-3xl ${getTextColor()} opacity-90`}
            variants={itemVariants}
          >
            {subtitle}
          </motion.p>
        )}
        {children && (
          <motion.div className="mt-6" variants={itemVariants}>
            {children}
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

export default PageHeader;
