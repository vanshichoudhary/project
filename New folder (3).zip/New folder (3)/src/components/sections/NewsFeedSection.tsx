import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion, useAnimation } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { ArrowRight, Mail, CheckCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import NewsCard from "@/components/cards/NewsCard";
import { subscribeToMailchimp } from "@/lib/mailchimp";

const NewsFeedSection = () => {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const { toast } = useToast();
  const controls = useAnimation();
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  useEffect(() => {
    if (inView) {
      controls.start("visible");
    }
  }, [controls, inView]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  };

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsSubmitting(true);
    try {
      const result = await subscribeToMailchimp(email);
      
      if (result.success) {
        setIsSuccess(true);
        toast({
          title: "Subscription successful!",
          description: result.message,
        });
        setEmail("");
      } else {
        throw new Error(result.message);
      }
    } catch (error: any) {
      toast({
        title: "Subscription failed",
        description: error.message || "There was an error subscribing to the newsletter.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const newsItems = [
    {
      title: "Nynexa Foundation Launches New STEM Education Initiative",
      date: "June 15, 2023",
      excerpt:
        "The Nynexa Foundation has announced a groundbreaking new program aimed at advancing STEM education across underserved communities worldwide.",
      imageUrl:
        "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80",
      category: "Education",
      link: "/news/stem-education-initiative",
    },
    {
      title: "Breakthrough in Quantum Computing Research",
      date: "May 28, 2023",
      excerpt:
        "Researchers funded by the Nynexa Foundation have achieved a significant breakthrough in quantum computing that could revolutionize the field.",
      imageUrl:
        "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&q=80",
      category: "Research",
      link: "/news/quantum-computing-breakthrough",
    },
    {
      title: "Global Climate Initiative Receives $500M Funding",
      date: "April 22, 2023",
      excerpt:
        "The Billionaire Fund has committed $500 million to a new global initiative aimed at developing innovative solutions to combat climate change.",
      imageUrl:
        "https://images.unsplash.com/photo-1534274988757-a28bf1a57c17?w=800&q=80",
      category: "Funding",
      link: "/news/climate-initiative-funding",
    },
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          animate={controls}
          initial="hidden"
          variants={containerVariants}
        >
          <motion.div
            variants={itemVariants}
            className="flex flex-col md:flex-row md:items-center md:justify-between mb-12"
          >
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                Latest News
              </h2>
              <p className="text-xl text-gray-700">
                Stay updated with the latest developments and announcements
              </p>
            </div>
            <Link
              to="/news"
              className="inline-flex items-center text-black-700 font-semibold hover:text-black-900 transition-colors mt-4 md:mt-0"
            >
              View all news
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </motion.div>

          <motion.div
            variants={containerVariants}
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            {newsItems.map((news, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                whileHover={{ y: -10 }}
                transition={{ duration: 0.3 }}
              >
                <NewsCard
                  title={news.title}
                  date={news.date}
                  excerpt={news.excerpt}
                  imageUrl={news.imageUrl}
                  category={news.category}
                  link={news.link}
                />
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            variants={itemVariants}
            className="mt-16 p-8 bg-gray-50 rounded-xl flex flex-col md:flex-row md:items-center md:justify-between border border-gray-200 shadow-sm"
          >
            <div className="mb-6 md:mb-0 md:mr-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                Subscribe to Our Newsletter
              </h3>
              <p className="text-gray-700">
                Get the latest updates on our work, events, and opportunities
                delivered to your inbox.
              </p>
            </div>
            {isSuccess ? (
              <div className="flex items-center space-x-2 text-black p-4 bg-green-50 rounded-lg">
                <CheckCircle className="h-6 w-6 text-green-500" />
                <p className="font-medium">Thank you for subscribing!</p>
              </div>
            ) : (
              <div className="flex flex-col w-full md:w-auto">
                <form onSubmit={handleSubscribe} className="flex">
                  <div className="relative flex-grow">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <Input
                      type="email"
                      placeholder="Your email address"
                      className="pl-10 bg-white border-gray-200 w-full"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                    <input
                      type="text"
                      tabIndex={-1}
                      name="b_1487cc549a49109c00fe60a80_93cd7be172"
                      style={{ position: "absolute", left: "-5000px" }}
                      aria-hidden="true"
                    />
                  </div>
                  <Button
                    type="submit"
                    size="lg"
                    variant="default"
                    className="ml-2 bg-black-700 hover:bg-black-800"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Subscribing...
                      </>
                    ) : (
                      "Subscribe"
                    )}
                  </Button>
                </form>
                <p className="text-xs text-gray-500 mt-2">
                  We respect your privacy. Unsubscribe at any time.
                </p>
              </div>
            )}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default NewsFeedSection;
