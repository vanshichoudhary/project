import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { motion, useAnimation } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { ArrowRight } from "lucide-react";
import PillarCard from "@/components/cards/PillarCard";

const CorePillarsSection = () => {
  const controls = useAnimation();
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  useEffect(() => {
    if (inView) {
      controls.start("visible");
    }
  }, [controls, inView]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  };

  const pillars = [
    {
      title: "Research & Development",
      description:
        "Pioneering breakthrough technologies and scientific advancements that address humanity's greatest challenges.",
      icon: "research",
      imageUrl:
        "https://images.unsplash.com/photo-1507413245164-6160d8298b31?w=800&q=80",
      linkUrl: "/work/research-development",
      linkText: "Explore Research",
    },
    {
      title: "Billionaire Fund",
      description:
        "Strategic investments in transformative global initiatives led by visionary philanthropists and innovators.",
      icon: "fund",
      imageUrl:
        "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80",
      linkUrl: "/work/billionaire-fund",
      linkText: "Learn About the Fund",
    },
    {
      title: "Education & STEM",
      description:
        "Empowering the next generation through educational initiatives focused on science, technology, engineering, and mathematics.",
      icon: "education",
      imageUrl:
        "https://images.unsplash.com/photo-1509062522246-3755977927d7?w=800&q=80",
      linkUrl: "/work/education-stem",
      linkText: "Discover Programs",
    },
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          animate={controls}
          initial="hidden"
          variants={containerVariants}
        >
          <motion.div variants={itemVariants} className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Core Pillars
            </h2>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto">
              Through these three strategic pillars, we're working to create a
              more equitable, sustainable, and innovative future for all of
              humanity.
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            {pillars.map((pillar, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                whileHover={{ y: -10 }}
                transition={{ duration: 0.3 }}
              >
                <PillarCard
                  title={pillar.title}
                  description={pillar.description}
                  icon={pillar.icon}
                  imageUrl={pillar.imageUrl}
                  linkUrl={pillar.linkUrl}
                  linkText={pillar.linkText}
                />
              </motion.div>
            ))}
          </motion.div>

          <motion.div variants={itemVariants} className="mt-16 text-center">
            <Link
              to="/about/vision-mission"
              className="inline-flex items-center text-black font-semibold hover:text-black-900 transition-colors"
            >
              Learn more about our vision and mission
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default CorePillarsSection;
