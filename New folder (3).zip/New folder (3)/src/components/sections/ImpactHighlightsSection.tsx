import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { motion, useAnimation } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { ArrowRight, TrendingUp, Users, Zap } from "lucide-react";
import { ImpactCard } from "@/components/cards/ImpactCard";

const ImpactHighlightsSection = () => {
  const controls = useAnimation();
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  useEffect(() => {
    if (inView) {
      controls.start("visible");
    }
  }, [controls, inView]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  };

  const stats = [
    {
      value: "$250M+",
      label: "Research Funding",
      icon: <TrendingUp className="h-6 w-6" />,
      color: "purple" as const,
    },
    {
      value: "120+",
      label: "Global Partners",
      icon: <Users className="h-6 w-6" />,
      color: "teal" as const,
    },
    {
      value: "35+",
      label: "Breakthrough Innovations",
      icon: <Zap className="h-6 w-6" />,
      color: "gold" as const,
    },
  ];

  const impactStories = [
    {
      title: "Breakthrough in Cellular Reprogramming",
      description:
        "Our funded research has led to a revolutionary technique that can reverse cellular aging, with profound implications for treating age-related diseases.",
      imageUrl:
        "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=800&q=80",
      category: "Research",
      link: "/impact/stories/cellular-reprogramming-breakthrough",
    },
    {
      title: "AI Safety Framework Adoption",
      description:
        "Our AI alignment framework has been adopted by leading tech companies, ensuring safer development of advanced artificial intelligence systems.",
      imageUrl:
        "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800&q=80",
      category: "Technology",
      link: "/impact/stories/ai-alignment-framework",
    },
    {
      title: "Global Scholars Program Expansion",
      description:
        "Our STEM education initiative has expanded to 25 new countries, providing opportunities for talented students from underserved communities.",
      imageUrl:
        "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80",
      category: "Education",
      link: "/impact/stories/global-scholars-expansion",
    },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          animate={controls}
          initial="hidden"
          variants={containerVariants}
        >
          <motion.div variants={itemVariants} className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Impact
            </h2>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto">
              Discover how our initiatives are transforming lives and advancing
              human progress across the globe.
            </p>
          </motion.div>

          {/* Stats Section */}
          <motion.div
            variants={containerVariants}
            className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                whileHover={{ y: -10 }}
                transition={{ duration: 0.3 }}
              >
                <ImpactCard
                  title={stat.label}
                  value={stat.value}
                  icon={stat.icon}
                  color={stat.color}
                />
              </motion.div>
            ))}
          </motion.div>

          {/* Impact Stories */}
          <motion.div
            variants={containerVariants}
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            {impactStories.map((story, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                whileHover={{ y: -10 }}
                transition={{ duration: 0.3 }}
              >
                <ImpactCard
                  title={story.title}
                  description={story.description}
                  imageUrl={story.imageUrl}
                  link={story.link}
                  color="default"
                />
              </motion.div>
            ))}
          </motion.div>

          <motion.div variants={itemVariants} className="mt-16 text-center">
            <Link
              to="/impact/stories"
              className="inline-flex items-center text-black font-semibold hover:text-black-900 transition-colors"
            >
              View all impact stories
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default ImpactHighlightsSection;
