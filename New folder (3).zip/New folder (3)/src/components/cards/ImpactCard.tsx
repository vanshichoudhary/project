import React from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, TrendingUp } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface ImpactCardProps {
  title?: string;
  value?: string;
  description?: string;
  trend?: number;
  icon?: React.ReactNode;
  color?: "default" | "purple" | "teal" | "gold";
  onClick?: () => void;
  imageUrl?: string;
  link?: string;
}

export const ImpactCard = ({
  title = "Lives Impacted",
  value,
  description = "People directly benefiting from our education initiatives worldwide",
  trend,
  icon = <TrendingUp size={20} />,
  color = "default",
  onClick,
  imageUrl,
  link,
}: ImpactCardProps) => {
  const colorVariants = {
    default: "bg-white hover:bg-gray-50",
    purple: "bg-purple-50 hover:bg-purple-100 border-purple-200",
    teal: "bg-teal-50 hover:bg-teal-100 border-teal-200",
    gold: "bg-amber-50 hover:bg-amber-100 border-amber-200",
  };

  const titleColorVariants = {
    default: "text-gray-600",
    purple: "text-purple-700",
    teal: "text-teal-700",
    gold: "text-amber-700",
  };

  const valueColorVariants = {
    default: "text-gray-900",
    purple: "text-purple-900",
    teal: "text-teal-900",
    gold: "text-amber-900",
  };

  const iconColorVariants = {
    default: "bg-gray-100 text-gray-700",
    purple: "bg-purple-100 text-purple-700",
    teal: "bg-teal-100 text-teal-700",
    gold: "bg-amber-100 text-amber-700",
  };

  // If imageUrl is provided, render a different card style
  if (imageUrl) {
    return (
      <motion.div
        whileHover={{ y: -5, transition: { duration: 0.2 } }}
        className="h-full"
      >
        <Card
          className={cn(
            "h-full cursor-pointer transition-all duration-200 border overflow-hidden",
            colorVariants[color],
          )}
          onClick={onClick}
        >
          <div className="relative h-48 overflow-hidden">
            <img
              src={imageUrl}
              alt={title}
              className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
            />
          </div>
          <CardHeader>
            <CardTitle className="text-xl font-bold text-gray-900">
              {title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription className="text-gray-600">
              {description}
            </CardDescription>
          </CardContent>
          <CardFooter>
            <a
              href={link}
              className="flex items-center text-sm font-medium text-purple-600 hover:text-purple-800 transition-colors"
            >
              Learn more
              <ArrowUpRight size={16} className="ml-1" />
            </a>
          </CardFooter>
        </Card>
      </motion.div>
    );
  }

  // Default stat card style
  return (
    <motion.div
      whileHover={{ y: -5, transition: { duration: 0.2 } }}
      className="h-full"
    >
      <Card
        className={cn(
          "h-full cursor-pointer transition-all duration-200 border-2",
          colorVariants[color],
        )}
        onClick={onClick}
      >
        <CardHeader className="flex flex-row items-start justify-between">
          <div>
            <CardTitle
              className={cn(
                "text-lg font-bold mb-1",
                titleColorVariants[color],
              )}
            >
              {title}
            </CardTitle>
            <CardDescription className="text-gray-500">
              {description}
            </CardDescription>
          </div>
          <div className={cn("p-2 rounded-full", iconColorVariants[color])}>
            {icon}
          </div>
        </CardHeader>
        <CardContent>
          {value && (
            <div
              className={cn("text-4xl font-bold", valueColorVariants[color])}
            >
              {value}
            </div>
          )}
          {trend && (
            <div className="flex items-center mt-2 text-sm">
              <span className={trend > 0 ? "text-green-600" : "text-red-600"}>
                {trend > 0 ? "+" : ""}
                {trend}%
              </span>
              <span className="ml-1 text-gray-500">from previous year</span>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <div className="flex items-center text-sm font-medium text-purple-600 hover:text-purple-800 transition-colors">
            View details
            <ArrowUpRight size={16} className="ml-1" />
          </div>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default ImpactCard;
