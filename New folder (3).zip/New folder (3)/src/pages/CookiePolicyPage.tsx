import React from "react";
import { motion } from "framer-motion";
import MainLayout from "@/components/layout/MainLayout";
import PageHeader from "@/components/shared/PageHeader";
import Breadcrumbs from "@/components/shared/Breadcrumbs";
import SEO from "@/components/shared/SEO";
import { Link } from "react-router-dom";

const CookiePolicyPage = () => {
  return (
    <MainLayout>
      <SEO
        title="Cookie Policy"
        description="Learn about how the Nynexa Foundation uses cookies and similar technologies on our website."
        keywords="Nynexa Foundation cookie policy, cookies, tracking technologies, web beacons, privacy"
      />

      <PageHeader
        title="Cookie Policy"
        subtitle="How we use cookies and similar technologies"
        backgroundImage="https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=1920&q=80"
      />

      <div className="container mx-auto px-4 py-12">
        <Breadcrumbs
          overrides={{
            "cookie-policy": "Cookie Policy",
          }}
        />

        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="space-y-8 prose prose-lg max-w-none"
          >
            <p className="text-lg text-gray-600">
              Last Updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
            </p>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">Introduction</h2>
              <p>
                The Nynexa Foundation ("we," "our," or "us") uses cookies and similar technologies on our website 
                at {" "}
                <a href="https://nynexafoundation.org" className="text-black font-medium underline">
                  nynexafoundation.org
                </a>{" "}
                (the "Site"). This Cookie Policy explains how we use cookies, what types of cookies we use, and how 
                you can control them.
              </p>
              <p>
                By using our Site, you consent to the use of cookies in accordance with this Cookie Policy. If you do 
                not accept the use of cookies, please disable them as explained below, or refrain from using our Site.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">What Are Cookies?</h2>
              <p>
                Cookies are small text files that are stored on your device (computer, tablet, or mobile) when you 
                visit websites. They are widely used to make websites work more efficiently, provide a better user 
                experience, and provide information to the owners of the site.
              </p>
              <p>
                Cookies can be "persistent" or "session" cookies. Persistent cookies remain on your device when you 
                go offline, while session cookies are deleted as soon as you close your web browser.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">Types of Cookies We Use</h2>
              <p>
                We use the following types of cookies on our Site:
              </p>

              <h3 className="text-xl font-semibold text-gray-900 mt-6">1. Essential Cookies</h3>
              <p>
                These cookies are necessary for the operation of our Site. They enable core functionality such as 
                security, network management, accessibility, and basic user preferences. You may disable these by 
                changing your browser settings, but this may affect how the Site functions.
              </p>
              <table className="min-w-full bg-white border border-gray-200 mb-6">
                <thead>
                  <tr>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700">Cookie Name</th>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700">Purpose</th>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700">Duration</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">XSRF-TOKEN</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">Used for security purposes to prevent cross-site request forgery</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">Session</td>
                  </tr>
                  <tr className="bg-gray-50">
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">session</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">Maintains user session information</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">Session</td>
                  </tr>
                </tbody>
              </table>

              <h3 className="text-xl font-semibold text-gray-900 mt-6">2. Performance and Analytics Cookies</h3>
              <p>
                These cookies collect information about how visitors use our Site, such as which pages they visit most 
                often and if they receive error messages. The information collected is aggregated and anonymous. We use 
                this data to improve our Site's performance.
              </p>
              <table className="min-w-full bg-white border border-gray-200 mb-6">
                <thead>
                  <tr>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700">Cookie Name</th>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700">Purpose</th>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700">Duration</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">_ga</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">Used by Google Analytics to distinguish users</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">2 years</td>
                  </tr>
                  <tr className="bg-gray-50">
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">_gid</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">Used by Google Analytics to distinguish users</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">24 hours</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">_gat</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">Used by Google Analytics to throttle request rate</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">1 minute</td>
                  </tr>
                </tbody>
              </table>

              <h3 className="text-xl font-semibold text-gray-900 mt-6">3. Functionality Cookies</h3>
              <p>
                These cookies allow our Site to remember choices you make (such as your username, language preference, 
                or region) and provide enhanced, personalized features. They may be set by us or by third-party providers 
                whose services we have added to our pages.
              </p>
              <table className="min-w-full bg-white border border-gray-200 mb-6">
                <thead>
                  <tr>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700">Cookie Name</th>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700">Purpose</th>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700">Duration</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">preferredTheme</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">Remembers your preferred theme (light/dark)</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">1 year</td>
                  </tr>
                  <tr className="bg-gray-50">
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">language</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">Remembers your language preference</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">1 year</td>
                  </tr>
                </tbody>
              </table>

              <h3 className="text-xl font-semibold text-gray-900 mt-6">4. Targeting/Advertising Cookies</h3>
              <p>
                These cookies record your visits to our Site, the pages you have visited, and the links you have followed. 
                We use this information to make our Site and the advertising displayed on it more relevant to your interests. 
                We may also share this information with third parties for this purpose.
              </p>
              <table className="min-w-full bg-white border border-gray-200 mb-6">
                <thead>
                  <tr>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700">Cookie Name</th>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700">Purpose</th>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700">Duration</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">_fbp</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">Used by Facebook to deliver advertisements</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">3 months</td>
                  </tr>
                  <tr className="bg-gray-50">
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">_ttp</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">Used for marketing attribution</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">1 year</td>
                  </tr>
                </tbody>
              </table>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">Third-Party Cookies</h2>
              <p>
                In addition to our own cookies, we may also use various third-party cookies to report usage statistics 
                of the Site, deliver advertisements, and so on. These cookies may include:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Google Analytics cookies for analyzing site traffic and user behavior</li>
                <li>Social media cookies from platforms like Facebook, Twitter, and LinkedIn to enable sharing functionality</li>
                <li>Advertising cookies from our marketing partners</li>
                <li>Payment processor cookies for donation processing</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">Other Tracking Technologies</h2>
              <p>
                In addition to cookies, we may use other similar technologies on our Site, such as:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>
                  <strong>Web Beacons:</strong> Small transparent graphic images that are used to track user behavior and engagement
                </li>
                <li>
                  <strong>Pixels:</strong> Tiny code snippets in our emails that allow us to know if an email has been opened
                </li>
                <li>
                  <strong>Local Storage:</strong> Similar to cookies but can store larger amounts of data
                </li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">Managing Cookies</h2>
              <p>
                Most web browsers allow you to control cookies through their settings. You can typically find these settings 
                in the "Options," "Preferences," or "Settings" menu of your browser. You can also:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Delete cookies from your device</li>
                <li>Block cookies by activating the setting on your browser that allows you to refuse all or some cookies</li>
                <li>Set your browser to notify you when you receive a cookie</li>
              </ul>
              <p className="mt-4">
                Please note that if you choose to block or delete cookies, you may not be able to access certain areas or 
                features of our Site, and some services may not function properly.
              </p>

              <h3 className="text-xl font-semibold text-gray-900 mt-6">How to Manage Cookies in Different Browsers</h3>
              <ul className="list-disc pl-6 space-y-2">
                <li>
                  <strong>Google Chrome:</strong> Settings &gt; Privacy and security &gt; Cookies and other site data
                </li>
                <li>
                  <strong>Mozilla Firefox:</strong> Options &gt; Privacy & Security &gt; Cookies and Site Data
                </li>
                <li>
                  <strong>Safari:</strong> Preferences &gt; Privacy &gt; Cookies and website data
                </li>
                <li>
                  <strong>Microsoft Edge:</strong> Settings &gt; Cookies and site permissions &gt; Cookies and site data
                </li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">Do Not Track Signals</h2>
              <p>
                Some browsers have a "Do Not Track" feature that lets you tell websites that you do not want to have your 
                online activities tracked. We currently do not respond to "Do Not Track" signals because there is not yet 
                a common understanding of how to interpret these signals across the industry. However, you can disable 
                cookies as described above.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">Updates to This Cookie Policy</h2>
              <p>
                We may update this Cookie Policy from time to time to reflect changes in technology, law, or our data 
                practices. Any changes will become effective when we post the revised Cookie Policy on our Site. 
                Your continued use of our Site following these changes means that you accept the revised Cookie Policy.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">More Information</h2>
              <p>
                For more information about how we protect your personal information, please review our {" "}
                <Link to="/privacy-policy" className="text-black font-medium underline">
                  Privacy Policy
                </Link>.
              </p>
              <p>
                If you have any questions or concerns about our use of cookies, please contact us at:
              </p>
              <div className="mt-2">
                <p>Nynexa Foundation</p>
                <p>123 Innovation Way</p>
                <p>New York, NY 10001</p>
                <p>United States</p>
                <p>
                  <a href="mailto:privacy@nynexafoundation.org" className="text-black font-medium underline">
                    privacy@nynexafoundation.org
                  </a>
                </p>
              </div>
            </section>
          </motion.div>
        </div>
      </div>
    </MainLayout>
  );
};

export default CookiePolicyPage; 