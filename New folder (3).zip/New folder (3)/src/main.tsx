// Make React available globally
import React from "react";
window.React = React;

// Import other dependencies
import * as ReactDOM from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { BrowserRouter } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";
import { AuthProvider } from "./contexts/AuthContext";
import { ClerkProvider } from "@clerk/clerk-react";
// Import mobile and navigation fixes
import { initMobileFixes } from "./utils/mobileFix";
import { initNavigationFixes } from "./utils/navigationFix";

// Force useLayoutEffect to be useEffect in SSR
if (typeof window === 'undefined') {
  React.useLayoutEffect = React.useEffect;
}

// Initialize fixes for mobile and navigation
if (typeof window !== 'undefined') {
  // Initialize after a small delay to ensure DOM is loaded
  setTimeout(() => {
    // Initialize mobile fixes (Samsung devices)
    initMobileFixes();
    // Initialize navigation fixes
    initNavigationFixes();
  }, 100);
}

// Get the Clerk publishable key
const clerkPubKey = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY;

// Initialize root element
const root = document.getElementById("root");
if (!root) {
  throw new Error("Root element not found");
}

// Inject React into window just to be extra sure
window.React = window.React || React;

// Create the root and render the app
try {
  const rootElement = ReactDOM.createRoot(root);
  rootElement.render(
    <React.StrictMode>
      <ClerkProvider 
        publishableKey={clerkPubKey}
        appearance={{
          variables: {
            colorPrimary: "black",
            borderRadius: "0.375rem",
          },
          elements: {
            formButtonPrimary: 
              "bg-black hover:bg-black-800 text-white py-2 px-4 rounded-md",
            card: "bg-white shadow-xl border border-gray-200 rounded-lg",
            logoBox: "hidden",
            logoImage: "hidden",
            header: "text-xl text-center font-bold mb-4",
            socialButtonsBlockButton: 
              "border border-gray-300 bg-white hover:bg-gray-50 text-black",
            formFieldLabel: "text-gray-700",
            formFieldInput: 
              "bg-white border border-gray-300 rounded-md focus:ring-2 focus:ring-black focus:border-transparent",
            dividerLine: "bg-gray-200",
            dividerText: "text-gray-500 mx-3",
            footerActionLink: "text-black hover:text-gray-600 underline",
            identityPreviewEditButtonIcon: "text-black",
            alert: "rounded-lg",
          }
        }}
        localization={{
          signIn: {
            phoneCode: {
              title: "Sign in to Nynexa Foundation",
            },
            start: {
              title: "Sign in to Nynexa Foundation",
              subtitle: "to continue to our platform",
            }
          }
        }}
        afterSignInUrl="/"
        afterSignUpUrl="/"
      >
        <HelmetProvider>
          <BrowserRouter>
            <AuthProvider>
              <App />
            </AuthProvider>
          </BrowserRouter>
        </HelmetProvider>
      </ClerkProvider>
    </React.StrictMode>
  );
  
  // Re-apply mobile and navigation fixes after React has rendered
  if (typeof window !== 'undefined') {
    setTimeout(() => {
      initMobileFixes();
      initNavigationFixes();
    }, 500);
  }
} catch (error) {
  console.error('React render error:', error);
  
  // Fallback rendering in case of error
  if (root) {
    root.innerHTML = `
      <div style="padding: 20px; font-family: system-ui, sans-serif;">
        <h1>Something went wrong</h1>
        <p>Please try refreshing the page or contact support if the issue persists.</p>
        <pre>${error instanceof Error ? error.message : String(error)}</pre>
      </div>
    `;
  }
}
